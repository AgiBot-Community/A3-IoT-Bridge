"""鉴权回调（对齐 Java ``AgentAuthCallback``）。

继承本类并实现 ``on_auth_state(app_id, code, msg)``，然后传给
``AgentSdk.register_auth(...)``。
"""

from __future__ import annotations


class AgentAuthCallback:
    """所有具体实现需要重载 ``on_auth_state``。"""

    def on_auth_state(self, app_id: str, code: int, msg: str) -> None:  # noqa: D401
        """``code == 0`` 表示鉴权成功，非 0 见错误码表。"""
        raise NotImplementedError
