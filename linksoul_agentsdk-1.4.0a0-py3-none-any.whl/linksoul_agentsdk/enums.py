"""SDK 枚举集合（对齐 Java ``com.agibot.aiem.sdk.enums``）。"""

from __future__ import annotations

from enum import Enum
from typing import Optional


class _ValueEnum(Enum):
    """``Enum`` 子类的公共基类——提供 ``of(value)`` 反查，并以 ``ILLEGAL`` 兜底。"""

    @classmethod
    def of(cls, value: Optional[str]) -> "_ValueEnum":
        if value is None:
            return cls.ILLEGAL  # type: ignore[attr-defined]
        for member in cls:
            if member.value == value:
                return member
        return cls.ILLEGAL  # type: ignore[attr-defined]


class AgentCallbackType(_ValueEnum):
    """与 Java ``AgentCallbackType`` 等价；当前公开 8 + PUSH_LISTEN。"""

    AUDIO_2_LLM = "audio2llm"
    AUDIO_2_TTS = "audio2tts"
    ASR_2_LLM = "asr2llm"
    ASR_2_TTS = "asr2tts"
    ASR_VIDEO_2_TTS = "asrVideo2tts"
    ASR_VIDEO_2_VLM = "asrVideo2vlm"
    AUDIO_VIDEO_2_TTS = "audioVideo2tts"
    AUDIO_VIDEO_2_VLM = "audioVideo2vlm"
    PUSH_LISTEN = "pushListen"
    ILLEGAL = "illegal"


class AgentPolicy(_ValueEnum):
    """交互策略，内部使用。"""

    PASSIVE = "passive"
    ACTIVE = "active"
    SIGNAL = "signal"
    ILLEGAL = "illegal"


class FlowMode(_ValueEnum):
    """任务流模式。"""

    SIMPLE = "simple"
    COMPLEX = "complex"
    ILLEGAL = "illegal"


class RobotState(_ValueEnum):
    """机器人在线状态。"""

    ONLINE = "online"
    OFFLINE = "offline"
    ILLEGAL = "illegal"


class AgentEventType(_ValueEnum):
    """WebSocket 消息事件类型。仅列出 v1.4.0 公开链路相关 + 公开主动流相关。"""

    BRIDGESDK_ROLE_REGISTER = "bridgesdk.role.register"
    BRIDGESDK_ROLE_REGISTERED = "bridgesdk.role.registered"

    AGENTSDK_APPID_META_BROADCAST = "agentsdk.appid_meta.broadcast"

    AGENTSDK_ROBOT_STATE_SYNC = "agentsdk.robot_state.sync"
    AGENTSDK_ROBOT_STATE_SYNCED = "agentsdk.robot_state.synced"

    AGENTSDK_REMOTE_STATE_SYNC = "agentsdk.remote_state.sync"

    AGENTSDK_AUDIO_REQUEST_START = "agentsdk.audio_request.start"
    AGENTSDK_AUDIO_REQUEST_STARTED = "agentsdk.audio_request.started"
    AGENTSDK_AUDIO_REQUEST_APPEND = "agentsdk.audio_request.append"
    AGENTSDK_AUDIO_REQUEST_COMMIT = "agentsdk.audio_request.commit"
    AGENTSDK_AUDIO_REQUEST_COMMITED = "agentsdk.audio_request.commited"
    AGENTSDK_VIDEO_IMAGE_REQUEST_APPEND = "agentsdk.video_image_request.append"
    AGENTSDK_VIDEO_H264_REQUEST_APPEND = "agentsdk.video_h264_request.append"

    AGENTSDK_ASR_REQUEST_TEXT = "agentsdk.asr_request.text"
    AGENTSDK_TTS_REQUEST_TEXT = "agentsdk.tts_request.text"

    AGENTSDK_GREET_REQUEST_FACE = "agentsdk.greet_request.face"
    AGENTSDK_GREET_REQUEST_VIDEO = "agentsdk.greet_request.video"
    AGENTSDK_GREET_REQUEST_SIGNAL = "agentsdk.greet_request.signal"
    AGENTSDK_GREET_RESPONSE_VLM_DELTA = "agentsdk.greet_response.vlm.delta"
    AGENTSDK_GREET_RESPONSE_VLM_DONE = "agentsdk.greet_response.vlm.done"
    AGENTSDK_GREET_RESPONSE_TTS_DELTA = "agentsdk.greet_response.tts.delta"
    AGENTSDK_GREET_RESPONSE_TTS_DONE = "agentsdk.greet_response.tts.done"

    AGENTSDK_ASR_RESPONSE_MIDDLE = "agentsdk.asr_response.middle"
    AGENTSDK_ASR_RESPONSE_FINAL = "agentsdk.asr_response.final"
    AGENTSDK_LLM_RESPONSE_ITEM_DELTA = "agentsdk.llm_response.item.delta"
    AGENTSDK_LLM_RESPONSE_ITEM_DONE = "agentsdk.llm_response.item.done"
    AGENTSDK_LLM_RESPONSE_DONE = "agentsdk.llm_response.done"
    AGENTSDK_VLM_RESPONSE_ITEM_DELTA = "agentsdk.vlm_response.item.delta"
    AGENTSDK_VLM_RESPONSE_ITEM_DONE = "agentsdk.vlm_response.item.done"
    AGENTSDK_VLM_RESPONSE_DONE = "agentsdk.vlm_response.done"
    AGENTSDK_XLM_RESPONSE_SKILL = "agentsdk.xlm_response.skill"
    AGENTSDK_XLM_RESPONSE_INTERRUPT = "agentsdk.xlm_response.interrupt"
    AGENTSDK_XLM_RESPONSE_CONTROL = "agentsdk.xlm_response.control"
    AGENTSDK_TTS_RESPONSE_ITEM_DELTA = "agentsdk.tts_response.item.delta"
    AGENTSDK_TTS_RESPONSE_ITEM_DONE = "agentsdk.tts_response.item.done"
    AGENTSDK_TTS_RESPONSE_DONE = "agentsdk.tts_response.done"

    AGENTSDK_STATE_REQUEST_META = "agentsdk.state_request.meta"

    AGENTSDK_FLOW_START_REQUEST = "agentsdk.flow_start.request"
    AGENTSDK_FLOW_START_REQUEST_ACK = "agentsdk.flow_start.request_ack"
    AGENTSDK_FLOW_START_EXECUTE_ACK = "agentsdk.flow_start.execute_ack"
    AGENTSDK_FLOW_TASK_REQUEST = "agentsdk.flow_task.request"
    AGENTSDK_FLOW_TASK_REQUEST_ACK = "agentsdk.flow_task.request_ack"
    AGENTSDK_FLOW_TASK_EXECUTE_ACK = "agentsdk.flow_task.execute_ack"
    AGENTSDK_FLOW_END_REQUEST = "agentsdk.flow_end.request"
    AGENTSDK_FLOW_END_REQUEST_ACK = "agentsdk.flow_end.request_ack"
    AGENTSDK_FLOW_INTERRUPT_REQUEST = "agentsdk.flow_interrupt.request"
    AGENTSDK_FLOW_INTERRUPT_REQUEST_ACK = "agentsdk.flow_interrupt.request_ack"

    AGENTSDK_ERROR = "agentsdk.error"
    ILLEGAL = "illegal"
