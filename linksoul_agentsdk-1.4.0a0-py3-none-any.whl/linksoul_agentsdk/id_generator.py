"""唯一 ID 生成器（对齐 Java ``IdGenerator``）。

格式：``<prefix>_`` + 21 个字符（大小写字母 + 数字），用 :mod:`secrets` 提供熵。
"""

from __future__ import annotations

import secrets
import string


_CHAR_POOL = string.ascii_letters + string.digits
_RANDOM_LENGTH = 21


def _generate(prefix: str) -> str:
    return prefix + "".join(secrets.choice(_CHAR_POOL) for _ in range(_RANDOM_LENGTH))


class IdGenerator:
    """静态工厂——所有方法均为 ``staticmethod``，与 Java 风格一致。"""

    RANDOM_LENGTH = _RANDOM_LENGTH

    @staticmethod
    def generate_flow_id() -> str:
        return _generate("flow_")

    @staticmethod
    def generate_event_id() -> str:
        return _generate("event_")

    @staticmethod
    def generate_item_id() -> str:
        return _generate("item_")

    @staticmethod
    def generate_pull_id() -> str:
        return _generate("pull_")

    @staticmethod
    def generate_signal_id() -> str:
        return _generate("signal_")
