"""``appId`` → 已注册的 ``AgentCallbackType`` 集合（用于 JWT 中声明）。"""

from __future__ import annotations

import threading
from typing import Dict, FrozenSet, Set

from ..enums import AgentCallbackType


class AgentSdkCallbackTypeMgr:
    """全局单例（class methods）。"""

    _lock = threading.Lock()
    _app_id_to_types: Dict[str, Set[AgentCallbackType]] = {}

    @classmethod
    def offer(cls, app_id: str, callback_type: AgentCallbackType) -> None:
        with cls._lock:
            cls._app_id_to_types.setdefault(app_id, set()).add(callback_type)

    @classmethod
    def get(cls, app_id: str) -> FrozenSet[AgentCallbackType]:
        with cls._lock:
            return frozenset(cls._app_id_to_types.get(app_id, set()))

    @classmethod
    def remove(cls, app_id: str) -> None:
        with cls._lock:
            cls._app_id_to_types.pop(app_id, None)

    @classmethod
    def _reset_for_test(cls) -> None:
        """仅用于单测——清空所有 appId 的映射。"""
        with cls._lock:
            cls._app_id_to_types.clear()
