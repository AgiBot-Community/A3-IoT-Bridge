"""``flow_id`` → :class:`TaskFlowRequest` 映射（主动任务流注册表）。"""

from __future__ import annotations

import threading
from typing import Dict, Optional

from ..active.task_flow import TaskFlowRequest


class AgentSdkTaskFlowMgr:
    _lock = threading.Lock()
    _flow_id_to_request: Dict[str, TaskFlowRequest] = {}

    @classmethod
    def offer_request(cls, flow_id: str, request: TaskFlowRequest) -> None:
        with cls._lock:
            cls._flow_id_to_request[flow_id] = request

    @classmethod
    def get_request(cls, flow_id: str) -> Optional[TaskFlowRequest]:
        with cls._lock:
            return cls._flow_id_to_request.get(flow_id)

    @classmethod
    def remove_request(cls, flow_id: str) -> None:
        with cls._lock:
            cls._flow_id_to_request.pop(flow_id, None)

    @classmethod
    def _reset_for_test(cls) -> None:
        with cls._lock:
            cls._flow_id_to_request.clear()
