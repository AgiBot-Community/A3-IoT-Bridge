"""Audio → ASR + LLM 文本输出。"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from ..agent_param import AgentParam
from ..enums import AgentCallbackType
from .base import AgentSdkResponse, PassiveCallback

if TYPE_CHECKING:
    from ..agent_sdk import AgentSdk


class Audio2LlmResponse(AgentSdkResponse):
    def on_asr_middle(self, event_id: str, middle_asr: str) -> None:
        self._response_asr_middle(event_id, middle_asr)

    def on_asr_final(self, event_id: str, final_asr: str) -> None:
        self._response_asr_final(event_id, final_asr)

    def on_llm_item_delta(self, event_id: str, item_id: str, text_delta: str) -> None:
        self._response_llm_item_delta(event_id, item_id, text_delta)

    def on_llm_item_done(self, event_id: str, item_id: str) -> None:
        self._response_llm_item_done(event_id, item_id)

    def on_llm_done(self, event_id: str) -> None:
        self._response_llm_done(event_id)

    def on_skill(
        self,
        event_id: str,
        item_id: str,
        skill_type: str,
        skill_name: str,
        skill_param: Optional[AgentParam],
    ) -> None:
        self._response_xlm_skill(event_id, item_id, skill_type, skill_name, skill_param)

    def on_interrupt(
        self, event_id: str, interrupt_type: str, interrupt_tips: Optional[str]
    ) -> None:
        self._response_xlm_interrupt(event_id, interrupt_type, interrupt_tips)


class Audio2LlmCallback(PassiveCallback):
    """音频流入 → ASR + LLM 文本输出。

    ``on_request`` 由 SDK 在内部线程调用，需用户子类实现。
    """

    def __init__(self, agent_sdk: "AgentSdk") -> None:
        super().__init__(agent_sdk)
        self.callback_type = AgentCallbackType.AUDIO_2_LLM

    def on_request(
        self,
        agent_id: str,
        event_id: str,
        flag: int,
        buf: Optional[bytes],
        param: AgentParam,
        response: Audio2LlmResponse,
    ) -> None:
        """``flag``: 0 VAD 开始 / 1 中间音频帧 / 2 VAD 结束。"""
        raise NotImplementedError
