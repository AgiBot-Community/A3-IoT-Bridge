"""音频 + 视频 → ASR + VLM + TTS 输出。"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from ..agent_param import AgentParam
from ..enums import AgentCallbackType
from .base import AgentSdkResponse, PassiveCallback

if TYPE_CHECKING:
    from ..agent_sdk import AgentSdk


class AudioVideo2TtsResponse(AgentSdkResponse):
    def on_asr_middle(self, event_id: str, middle_asr: str) -> None:
        self._response_asr_middle(event_id, middle_asr)

    def on_asr_final(self, event_id: str, final_asr: str) -> None:
        self._response_asr_final(event_id, final_asr)

    def on_vlm_item_delta(self, event_id: str, item_id: str, text_delta: str) -> None:
        self._response_vlm_item_delta(event_id, item_id, text_delta)

    def on_vlm_item_done(self, event_id: str, item_id: str) -> None:
        self._response_vlm_item_done(event_id, item_id)

    def on_vlm_done(self, event_id: str) -> None:
        self._response_vlm_done(event_id)

    def on_tts_item_delta(self, event_id: str, item_id: str, audio: bytes) -> None:
        self._response_tts_item_delta(event_id, item_id, audio)

    def on_tts_item_done(self, event_id: str, item_id: str) -> None:
        self._response_tts_item_done(event_id, item_id)

    def on_tts_done(self, event_id: str) -> None:
        self._response_tts_done(event_id)

    def on_skill(
        self, event_id: str, item_id: str, skill_type: str, skill_name: str,
        skill_param: Optional[AgentParam],
    ) -> None:
        self._response_xlm_skill(event_id, item_id, skill_type, skill_name, skill_param)

    def on_interrupt(
        self, event_id: str, interrupt_type: str, interrupt_tips: Optional[str]
    ) -> None:
        self._response_xlm_interrupt(event_id, interrupt_type, interrupt_tips)


class AudioVideo2TtsCallback(PassiveCallback):
    """全模态端到端：音频+视频输入，ASR+VLM+TTS 输出。"""

    def __init__(self, agent_sdk: "AgentSdk") -> None:
        super().__init__(agent_sdk)
        self.callback_type = AgentCallbackType.AUDIO_VIDEO_2_TTS

    def on_request(
        self,
        agent_id: str,
        event_id: str,
        flag: int,
        buf: Optional[bytes],
        param: AgentParam,
        response: AudioVideo2TtsResponse,
    ) -> None:
        raise NotImplementedError
